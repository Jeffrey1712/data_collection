import asyncio

async def main():
    print("Hello!")
    
main()
print("Goodbye!")