def main():
    print("Hello!")
    
main()

print("Goodbye!")