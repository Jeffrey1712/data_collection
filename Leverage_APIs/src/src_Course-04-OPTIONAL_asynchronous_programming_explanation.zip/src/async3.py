import asyncio

async def main():
    print("Hello!")
    
asyncio.run(main())
print("Goodbye!")